package step1_05.controlStatement;


/*
 * # 당첨복권[1단계] 30%의 당첨확률
 */


public class IfEx15_문제 {

	public static void main(String[] args) {
	
		
	}

}
